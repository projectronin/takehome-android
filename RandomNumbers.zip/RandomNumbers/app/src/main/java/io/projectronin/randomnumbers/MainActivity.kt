/*
 * Copyright (c) 2020. Project Rōnin
 */

package io.projectronin.randomnumbers

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import io.projectronin.randomnumbers.utilities.RandomNumberGenerator

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        Log.d("ProjectRonin", "onCreate")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val mainTextView: TextView = findViewById(R.id.mainTextView)
        val randomValuesList = RandomNumberGenerator.generate(1)
        mainTextView.text = randomValuesList[0].toString()
    }

    override fun onStart() {
        Log.d("ProjectRonin", "onStart")
        super.onStart()
    }

    override fun onStop() {
        Log.d("ProjectRonin", "onStop")
        super.onStop()
    }

    override fun onDestroy() {
        Log.d("ProjectRonin", "onDestroy")
        super.onDestroy()
    }
}
