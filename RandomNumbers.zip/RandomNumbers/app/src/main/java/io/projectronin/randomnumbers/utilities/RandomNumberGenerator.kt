/*
 * Copyright (c) 2020. Project Rōnin
 */

package io.projectronin.randomnumbers.utilities

import kotlin.random.Random

class RandomNumberGenerator {

    companion object {

        /**
         * @param size the number of random numbers to generate
         * @return a List of random numbers of the given size input
         */
        fun generate(size: Int): List<Int> {
            val values = ArrayList<Int>(size)

            for (i in 0 until size) {
                values.add(Random.nextInt())
            }

            return values
        }
    }
}