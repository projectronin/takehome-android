/*
 * Copyright (c) 2020. Project Rōnin
 */

package io.projectronin.randomnumbers.utilities

import org.junit.Assert.*
import org.junit.Test

class RandomNumberGeneratorTest {

    @Test
    fun `generate 10 random numbers`() {
        val valuesList = RandomNumberGenerator.generate(10)
        assertEquals(10, valuesList.size)
    }

    @Test
    fun `generate 10,000 random numbers`() {
        val valuesList = RandomNumberGenerator.generate(10000)
        assertEquals(10000, valuesList.size)
    }

    @Test
    fun `generate 10,000,000 random numbers`() {
        val valuesList = RandomNumberGenerator.generate(10000000)
        assertEquals(10000000, valuesList.size)
    }

    @Test
    fun `generate 2 different list of 10 random numbers`() {
        val aList = RandomNumberGenerator.generate(10)
        val bList = RandomNumberGenerator.generate(10)
        assertNotEquals(aList, bList)
    }
}
